import java.util.*; 

public class SelectionSort
{
    public static void main(String[] args)
    {
        int[] x = {1, 3, -2, 10, 5, 4, 7, 9 };
        
        System.out.print("BEFORE: ");
        printArray( x );
        
        //sort the list
        selectionSort(x);
        
        System.out.print("AFTER:  ");
        printArray( x );
        
    }
    
    public static void printArray( int[] x )
    {
        //display the list
        for(int i = 0; i < x.length; i++)
            System.out.printf( "%3d ", x[i]);
        System.out.println();
    }
    
    public static void selectionSort( int[] x)
    {        
       // ADD CODE HERE 
    }
    
}